
from serial import EIGHTBITS, PARITY_NONE, STOPBITS_ONE
import serial
import time
import datetime
import sys
import yaml
import requests
import json

def ASCIItoHEX(ascii):
	hexa = ""
	
	for i in range(len(ascii)):
		
		ch = ascii[i]
		
		in1 = ord(ch)
		
		part = hex(in1).lstrip("0x").rstrip("L")
		
		hexa += part
	
	#result = '1d6b49'+hexa+'7a41'
	result = hexa
	return result

ser = serial.Serial('/dev/ttyUSB0', 9600, EIGHTBITS, PARITY_NONE, STOPBITS_ONE)
seal_no = sys.argv[1]
fseal_no = ASCIItoHEX(seal_no)
print(fseal_no)

#byte of seal no
line = bytes.fromhex(fseal_no)
ser.write(line)
#printer code 128 CODE A
instruction = bytes.fromhex('1d6b490e7b41')
ser.write(instruction)

ser.write(b'\x1B\x64\x05')
ser.write(b'\x1B\x6D')
ser.close()


	
