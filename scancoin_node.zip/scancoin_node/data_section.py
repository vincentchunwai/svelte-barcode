from escpos import *
import sys

p = printer.File("/dev/usb/lp0")
p.set(align="LEFT")
args = sys.argv[2:]
list_facevalue = []
list_qty = []
currency = sys.argv[1]
total = 0
 
for i, arg in enumerate(args, start = 0):
	if i % 2 == 0:
		list_facevalue.append(arg)
	else:
		list_qty.append(arg)

p.text("CUR. \t\x20 PCS \t\t DENOM \x20\x20 AMOUNT\n")
p.text("------------------------------------------------\n")
for i in range(len(list_facevalue)):
	total += (float(list_facevalue[i]) * int(list_qty[i],10))
		
for i in range(len(list_facevalue)):
	line_sum = float(list_facevalue[i]) * int(list_qty[i], 10)
	format_line_sum = "%.2f" % line_sum
	line = '' + currency + '\t\x20\x20' + str(list_facevalue[i]) + '\t\t\x20' + list_qty[i] + ' \t\x20\x20\x20' + format_line_sum + '\n\n'
	p.text(line)
p.text("------------------------------------------------\n")

format_total = "%.2f" % total
p.text(currency + " TOTAL:  " + format_total + "\n")
p.text("------------------------------------------------\n\n")
p.close()



