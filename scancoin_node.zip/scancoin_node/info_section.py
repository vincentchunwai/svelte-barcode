from escpos import *
import sys
import time
import datetime

p = printer.File("/dev/usb/lp0")
now = datetime.datetime.now()
datetime_str = now.strftime("%Y-%m-%d %H:%M:%S")

if sys.argv[1] != "Nil":
	seal = sys.argv[1]
else:
	seal = "None"
	
p.set(align="LEFT")
p.text("Seal:  ")
p.text(seal)
p.text("\n\n")
p.text("Date:  ")
p.text(datetime_str)
p.text("\n\n")
p.text("------------------------------------------------\n")
p.close()
