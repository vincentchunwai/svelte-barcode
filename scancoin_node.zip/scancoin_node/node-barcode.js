const escpos = require('escpos');

escpos.Serial = require('escpos-serialport');


const device = new escpos.Serial('/dev/ttyUSB0');

const printer = new escpos.Printer(device);

device.open(function(error){
	printer
	.font('a')
	.barcode('141095013831', 'CODE39')
});
