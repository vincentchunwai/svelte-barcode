
from escpos import *

p = printer.File("/dev/usb/lp0")
p.set(align="CENTER")
p.text("\n\n Printer Ready! \n\n")
p.cut()
p.close()
