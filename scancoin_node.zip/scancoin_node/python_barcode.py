from escpos.printer import Serial
import sys


p = Serial(devfile='/dev/ttyUSB0',
	baudrate=9600,
	bytesize=8,
	parity='N',
	stopbits=1,
	timeout=1.00,
	dsrdtr=False)
	
print(sys.argv[1])
p.barcode(str(sys.argv[1]), 'CODE39', 64, 2, '', '')
