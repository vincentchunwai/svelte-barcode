import evdev
import re
import requests
import json
import os

URL = "http://localhost:8085/send_seal"
data = {'seal': "Nil"}

path = '/dev/hidraw0'
command = f'sudo chmod 666 {path}'

def readHID():
	code = os.system(command)
	tempstring = ""
	capsEnable = False
	devices = [evdev.InputDevice(fn) for fn in evdev.list_devices()]
	device = evdev.InputDevice(devices[0])
	
	for d in devices:
		print(d.fn, d.name, d.phys)
		if d.name == "SuperLead 7201":
			device = evdev.InputDevice(d)
	
	#print(device)
	
	
	print('before loop')
	for event in device.read_loop():
		#print(event)
		if event.type == evdev.ecodes.EV_KEY:
			tempevent = str(evdev.categorize(event))
			#print(tempevent)
			listtempevent = tempevent.split(',')
			
			x = re.search(r"\bKEY_(\w+)", listtempevent[1])
			text1 = str(x.group(1))
			#print(text1)
			if text1 == "LEFTSHIFT" and listtempevent[2].strip() == 'down':
				capsEnable = True
			elif text1 == "LEFTSHIFT" and listtempevent[2].strip() == 'up':
				capsEnable = False
			elif text1 == "ENTER" and listtempevent[2].strip() == 'down':
				print(tempstring)
				data['seal'] = tempstring
				print('break')
				break
			elif listtempevent[2].strip() == 'down':
				if capsEnable == True:
					tempstring += text1.upper()
				elif capsEnable == False:
					tempstring += text1.lower()
				
		
	r = requests.post(url=URL, json=data )
	
	print('post')
	
while True:
	try:
		readHID()
	except:
		print('error')
