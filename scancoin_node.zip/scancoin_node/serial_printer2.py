
from escpos import *
import time
import sys
import datetime

p = printer.File("/dev/usb/lp0")
args = sys.argv[3:]
now = datetime.datetime.now()
datetime_str = now.strftime("%Y-%m-%d %H:%M:%S").encode('utf-8')
seal = sys.argv[1]
if seal != "Nil":
	pass
else:
	seal = "None"
	
"""
if not args:
	p.text('Error: no arguments provided')
	p.close()
"""	

total = 0
list_facevalue = []
list_qty = []
"""
for i, arg in enumerate(args, start = 0):
	if i % 2 == 0:
		list_facevalue.append(arg)
	else:
		list_qty.append(arg)
"""		
#for i in range(len(list_facevalue)):
	#total += (float(list_facevalue[i]) * int(list_qty[i],10))
#ser.write(b'\x1D\x21\x01') #initialize font height and width
#time.sleep(0.5)
p.set(align="LEFT")
p.text("Seal:  ")
p.text(seal)
p.text("\n\n")
p.text("Date:  ")
p.text(datetime_str)
p.text("\n\n")
p.text("------------------------------------------------\n")
p.text("DENOM \x20 \x20 \x20 \x20 \x20 PCS \x20 \x20 \x20 \x20 \x20 \x20 \x20 AMOUNT")
p.cut()
p.close()

"""
format_total = "%.2f" % total
if arg1 == "None":
	#line0 = b' ' + arg1.encode() + b' \t\t\t\t' + bytes(str(total), 'utf-8') + b'\n'
	line0 = b' ' + arg1.encode() + b' \t\t\t\t' + bytes(format_total, 'utf-8') + b'\n'
else:
	#line0 = b' ' + arg1.encode() + b' \t\t\t\x20' + bytes(str(total), 'utf-8') + b'\n'
	line0 = b' ' + arg1.encode() + b' \t\t\t\x20' + bytes(format_total, 'utf-8') + b'\n'
ser.write(line0)
ser.write(b'---------------------------------------------\n')

#ser.write(b'\x1B\x64\x05') #Feed paper 5 lines
ser.write(b'CUR. \x20 DENOMI. \t\t QTY \t VALUE \n')
currency = sys.argv[2].encode()
for i in range(len(list_facevalue)):
	line_sum = float(list_facevalue[i]) * int(list_qty[i], 10)
	format_line_sum = "%.2f" % line_sum
	line = b'' + currency + b'\t' + bytes(str(list_facevalue[i]), 'utf-8') + b' \t\t\x20' + list_qty[i].encode() + b' \t\x20' + bytes(format_line_sum, 'utf-8') + b'\n\n'
	ser.write(line)

ser.write(b'---------------------------------------------\n')


ser.write(b'\x1B\x64\x05') #Feed paper 5 lines
ser.write(b'\x1B\x6D') #Full cut

ser.close()
"""
