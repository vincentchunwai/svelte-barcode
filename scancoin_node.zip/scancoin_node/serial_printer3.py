from escpos import *
import serial
import time
import datetime
import sys
import yaml
import requests
import json
import subprocess



#ser = serial.Serial('/dev/ttyUSB0', 9600, EIGHTBITS, PARITY_NONE, STOPBITS_ONE)
p = printer.File("/dev/usb/lp0")
p.set(align="CENTER")
seal = sys.argv[1]

def load_config(file_path):
	with open(file_path, 'r') as file:
		config = yaml.safe_load(file)
	return config

config = load_config('config.yml')
urelay_get_api = config['uRelay_api_get']
url = f'{urelay_get_api}{seal}'

response = requests.get(url)

p.text('Seal:' + seal + "\n")

if response.status_code == 200:
	try:
		result = response.json()
		print('Json response', result)
		if result.get('cust_ref') is not None:
			cust_ref = result['cust_ref']
			site_ref = result['site_ref']
			#print(cust_ref)
			#print(site_ref)
			line_cust_ref = 'Customer Ref: \x20' + cust_ref + '\n'
			line_site_ref = 'Site Ref: \x20' + site_ref + '\n'
			p.text(line_cust_ref)
			p.text(line_site_ref)
		else:
			p.text('Customer ref: Null\n')
			p.text('Site ref: Null\n')

	except requests.exceptions.RequestException as e:
		print('Error:', e)
		
		
else:
	print('200')
	
print(sys.argv[1])
p.barcode(str(sys.argv[1]), 'CODE39', 64, 2, '', '')
p.text('\n\n')
p.close()


