
from escpos import *
import time
import datetime
import sys
import yaml
import requests
import json

p = printer.File("/dev/usb/lp0")
argv1 = sys.argv[1]

if argv1 == "200":
	p.text('Data upload success: \x20')
	p.text('status (')
	p.text(argv1)
	p.text(')')
	p.text('\n')
else:
	p.text('Error:')
	p.text(argv1)
	p.text('\n')

p.cut()
p.close()
